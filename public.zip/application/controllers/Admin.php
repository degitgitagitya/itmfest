<?php
/**
 * Created by PhpStorm.
 * User: degit
 * Date: 3/7/2019
 * Time: 4:34 PM
 */

class Admin extends CI_Controller
{

    

}